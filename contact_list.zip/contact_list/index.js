// const db = require('./config/mongoose.js');
const express = require('express');
const path = require('path');
const port = 8000;
const db = require('./config/mongoose');
const Contact = require('./models/contact');
const app = express();
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views'));
app.use(express.urlencoded());
app.use(express.static('assets'));
// making middleware of our own

// app.use(function(req,res,next)
// {
//     console.log("This is  middleware 1");
//     next();
// });
// app.use(function(req,res,next)
// {
//     console.log("This is  middleware 2");
//     next();
// });

var contactList= [
    {
        name:"Asad",
        phone:"111111111"
    },
    {
        name: "Tony Stark",
        phone:"798465231"
    },
    {
        name: "Tanya Stark",
        phone:"798465236453148513"
    }
]
app.get('/',function(req,res)
{
    // console.log(req);
    // console.log(__dirname);
    // res.send('<h1>Cool is  is running or is it?</h1>');
    
    Contact.find({},function(err,contacts)
    {
        if(err)
        {
            console.log("Error In Fetching Contacts");
            return;
        }
        else
        {
            return res.render('home',{
                title:"Contact List",
                contact_list:contacts
            });
        }
    });
});
app.get('/practice',function(req,res)
{
    return res.render('practice',
    {
        title:"let us play with ejs"
    });
});
app.post('/create-contact',function(req,res)
{
    // contactList.push(req.body
    //     // {
    //     //     name:req.body.name,
    //     //     Phone:req.body.phone
    //     // }
    // );
    Contact.create({
        name:req.body.name,
        phone:req.body.phone
    },function(err,newContact)
    {
        if(err)
        {
            console.log("ERROR IN CREATING THE DATABASE");
            return;
        }
            console.log("**********",newContact);
            return res.redirect('back');
    });
});
//for deleting the contact 
app.get('/delete-contact',function(req,res)
{
    //get the query form the url
    console.log(req.query);
    // let phone =req.query.phone;
    // let contactIndex = contactList.findIndex(contact => contact.phone == phone);
       // if(contactIndex!=-1)
    // {
    //     contactList.splice(contactIndex, 1);
    // }
    //return res.redirect('back');

    // Finding ID from the query in the url

    let id = req.query.id;
    Contact.findByIdAndDelete(id,function(err)
    {
        if(err)
        {
            console.log("error in deleting the Contacts from the database");
            return;
        }
        
            console.log("Contact deleted");
            return res.redirect('back');

    });
 
});
app.listen(port,function(err)
{
    if(err)
    {
        console.log('error in running a server', err);
    }
    console.log('Yup!My Express is running on port',port);
});