console.log('My js has been loaded');
